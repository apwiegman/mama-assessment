package com.mamamoney.ussd.infrastructure.api.ussd;

import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.application.utils.exceptions.ValidationException;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdRequest;
import com.mamamoney.ussd.infrastructure.validator.Validator;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
public class UssdServiceMapperTest {

    @Autowired
    UssdServiceMapper ussdServiceMapper;

    @Autowired
    private Validator validator;

    /**
     * Normal mapping test without validation errors
     */
    @Test
    public void mapCreateUssdRequestTest(){
        //truth
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27836541234","#AA1236","");
        //input
        CreateUssdRequest createUssdRequest = new CreateUssdRequest();
        createUssdRequest.setSessionId("#AA1236");
        createUssdRequest.setMsisdn("27836541234");
        createUssdRequest.setUserEntry("");
        UssdRequestObject testOutput = ussdServiceMapper.mapCreateUssdRequest(createUssdRequest);
        //test
        assertEquals(testOutput.getSessionId(),ussdRequestObject.getSessionId());
        assertEquals(testOutput.getMsisdn(),ussdRequestObject.getMsisdn());
        assertEquals(testOutput.getUserEntry(),ussdRequestObject.getUserEntry());
    }
    /**
     * Mapping test with msisdn length error
     */
    @Test
    public void mapCreateUssdRequestTestWithUserMsisdnLengthError(){
        //truth
        ValidationException expectedValidationException = new ValidationException("#AA1236", "invalid msisdn - should be between 6 and 18 characters");
        //input
        CreateUssdRequest createUssdRequest = new CreateUssdRequest();
        createUssdRequest.setSessionId("#AA1236");
        createUssdRequest.setMsisdn("2783654123400000000");
        createUssdRequest.setUserEntry("");
        ValidationException exception = assertThrows(ValidationException.class,() -> {ussdServiceMapper.mapCreateUssdRequest(createUssdRequest);});
        //test
        assertEquals(exception.getMessage(),expectedValidationException.getMessage());
        assertEquals(exception.getSessionId(),expectedValidationException.getSessionId());
    }
    /**
     * Mapping test sessionId length error
     */
    @Test
    public void mapCreateUssdRequestTestWithSessionIdLengthError(){
        //truth
        ValidationException expectedValidationException = new ValidationException("#AA12", "invalid sessionId - should be between 6 and 40 characters");
        //input
        CreateUssdRequest createUssdRequest = new CreateUssdRequest();
        createUssdRequest.setSessionId("#AA12");
        createUssdRequest.setMsisdn("27836541234");
        createUssdRequest.setUserEntry("");
        ValidationException exception = assertThrows(ValidationException.class,() -> {ussdServiceMapper.mapCreateUssdRequest(createUssdRequest);});
        //test
        assertEquals(exception.getMessage(),expectedValidationException.getMessage());
        assertEquals(exception.getSessionId(),expectedValidationException.getSessionId());
    }
    /**
     * Mapping test sessionId null error
     */
    @Test
    public void mapCreateUssdRequestTestWithSessionIdNullError(){
        //truth
        ValidationException expectedValidationException = new ValidationException(null, "sessionId is a required field");
        //input
        CreateUssdRequest createUssdRequest = new CreateUssdRequest();
        createUssdRequest.setSessionId(null);
        createUssdRequest.setMsisdn("27836541234");
        createUssdRequest.setUserEntry("");
        ValidationException exception = assertThrows(ValidationException.class,() -> {ussdServiceMapper.mapCreateUssdRequest(createUssdRequest);});
        //test
        assertEquals(exception.getMessage(),expectedValidationException.getMessage());
        assertEquals(exception.getSessionId(),expectedValidationException.getSessionId());
    }
    /**
     * Mapping test msisdn null error
     */
    @Test
    public void mapCreateUssdRequestTestWithMsisdnNullError(){
        //truth
        ValidationException expectedValidationException = new ValidationException("#AA12456", "msisdn is a required field");
        //input
        CreateUssdRequest createUssdRequest = new CreateUssdRequest();
        createUssdRequest.setSessionId("#AA12456");
        createUssdRequest.setMsisdn(null);
        createUssdRequest.setUserEntry("");
        ValidationException exception = assertThrows(ValidationException.class,() -> {ussdServiceMapper.mapCreateUssdRequest(createUssdRequest);});
        //test
        assertEquals(exception.getMessage(),expectedValidationException.getMessage());
        assertEquals(exception.getSessionId(),expectedValidationException.getSessionId());
    }
    /**
     * Mapping test with sessionId black error
     */
    @Test
    public void mapCreateUssdRequestTestWithSessionIdBlankError(){
        //truth
        ValidationException expectedValidationException = new ValidationException("", "invalid sessionId - should be between 6 and 40 characters");
        //input
        CreateUssdRequest createUssdRequest = new CreateUssdRequest();
        createUssdRequest.setSessionId("");
        createUssdRequest.setMsisdn("27836541234");
        createUssdRequest.setUserEntry("");
        ValidationException exception = assertThrows(ValidationException.class,() -> {ussdServiceMapper.mapCreateUssdRequest(createUssdRequest);});
        //test
        assertEquals(exception.getMessage(),expectedValidationException.getMessage());
        assertEquals(exception.getSessionId(),expectedValidationException.getSessionId());
    }
    /**
     * TBC
     */



}
