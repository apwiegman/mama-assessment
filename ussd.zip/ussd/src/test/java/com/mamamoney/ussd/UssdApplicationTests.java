package com.mamamoney.ussd;

import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.infrastructure.api.ussd.UssdServiceMapper;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdRequest;
import com.mamamoney.ussd.infrastructure.validator.Validator;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.Assert.assertEquals;


@SpringBootTest
public class UssdApplicationTests {


}
