package com.mamamoney.ussd.infrastructure.api.ussd;

import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.application.service.UssdServiceImpl;
import com.mamamoney.ussd.application.utils.exceptions.ValidationException;
import com.mamamoney.ussd.domain.persistence.entities.MenuEntity;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdResponse;
import com.mamamoney.ussd.infrastructure.persistence.Repository;
import com.mamamoney.ussd.infrastructure.validator.Validator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
public class UssdServiceAdaptorTest {
    @Autowired
    private UssdServiceAdapter ussdServiceAdapter;

    @Autowired
    private UssdServiceImpl ussdServiceImpl;

    @Autowired
    private Repository repository;

    @Autowired
    private UssdServiceMapper ussdServiceMapper;


    /**
     * Normal test for new client in menu #1
     */
    @Test
    public void handleCreateUssdRequestNormalTest1() {
        //truth
        CreateUssdResponse truth = new CreateUssdResponse();
        truth.setMessage("Welcome to Mama Money! Where would you like to send money to? \n1) Kenya\n2) Malawi");
        truth.setSessionId("#AA1236");
        //input
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27821231236", "#AA1236", "1");

        CreateUssdResponse testOutput = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);

        //perform tests
        assertEquals(truth.getSessionId(),testOutput.getSessionId());
        assertEquals(truth.getMessage(),testOutput.getMessage());

    }

    /**
     * Normal test for new client in menu #2 option Kenya
     */
    @Test
    public void handleCreateUssdRequestNormalTest2KenyaEntry() {
        //truth
        CreateUssdResponse truth = new CreateUssdResponse();
        truth.setMessage("How much money (in Rands) would you like to send to Kenya?");
        truth.setSessionId("#AA1237");
        //input
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27821231237", "#AA1237", "1");
        CreateUssdResponse testOutput1 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);
        CreateUssdResponse testOutput2 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);

        //perform tests
        assertEquals(testOutput2.getSessionId(),truth.getSessionId());
        assertEquals(testOutput2.getMessage(),truth.getMessage());

    }

    /**
     * Normal test for new client in menu #2 option Kenya
     */
    @Test
    public void handleCreateUssdRequestNormalTest2MalawiEntry() {
        //truth
        CreateUssdResponse truth = new CreateUssdResponse();
        truth.setMessage("How much money (in Rands) would you like to send to Malawi?");
        truth.setSessionId("#AA1238");
        //input
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27821231238", "#AA1238", "");
        CreateUssdResponse testOutput1 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);
        UssdRequestObject ussdRequestObject2 = new UssdRequestObject("27821231238", "#AA1238", "2");
        CreateUssdResponse testOutput2 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject2);

        //perform tests
        assertEquals(testOutput2.getSessionId(),truth.getSessionId());
        assertEquals(testOutput2.getMessage(),truth.getMessage());

    }

    /**
     * Invalid entry test for new client in menu #2
     */
    @Test
    public void handleCreateUssdRequestInvalidTest2Entry() {
        //truth
        CreateUssdResponse truth = new CreateUssdResponse();
        truth.setMessage("0 is not a valid entry. Welcome to Mama Money! Where would you like to send money to? \n1) Kenya\n2) Malawi");
        truth.setSessionId("#AA1338");
        //input
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27821231238", "#AA1338", "");
        CreateUssdResponse testOutput1 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);
        UssdRequestObject ussdRequestObject2 = new UssdRequestObject("27821231238", "#AA1338", "0");
        ValidationException exception = assertThrows(ValidationException.class,() -> {ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject2);});

        //perform tests
        assertEquals(exception.getSessionId(),truth.getSessionId());
        assertEquals(exception.getMessage(),truth.getMessage());

    }

    /**
     * Normal test for new client in menu #3 send R100.45 to Kenya
     */
    @Test
    public void handleCreateUssdRequestNormalTest3KenyEntry() {
        //truth
        CreateUssdResponse truth = new CreateUssdResponse();
        truth.setMessage("Your person you are sending to will receive: KES 612.75\n1) OK");
        truth.setSessionId("#AA1239");
        //input
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27821231239", "#AA1239", "");
        CreateUssdResponse testOutput1 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);
        UssdRequestObject ussdRequestObject2 = new UssdRequestObject("27821231239", "#AA1239", "1");
        CreateUssdResponse testOutput2 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject2);
        UssdRequestObject ussdRequestObject3 = new UssdRequestObject("27821231239", "#AA1239", "100.45");
        CreateUssdResponse testOutput3 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject3);
        //perform tests
        assertEquals(truth.getSessionId(),testOutput3.getSessionId());
        assertEquals(truth.getMessage(),testOutput3.getMessage());


    }

    /**
     * Normal test for new client in menu #3 send R100.45 to Malawi
     */
    @Test
    public void handleCreateUssdRequestNormalTest3MalawiEntry() {
        //truth
        CreateUssdResponse truth = new CreateUssdResponse();
        truth.setMessage("Your person you are sending to will receive: MWK 4269.13\n1) OK");
        truth.setSessionId("#AA1240");
        //input
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27821231240", "#AA1240", "");
        CreateUssdResponse testOutput1 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);
        UssdRequestObject ussdRequestObject2 = new UssdRequestObject("27821231240", "#AA1240", "2");
        CreateUssdResponse testOutput2 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject2);
        UssdRequestObject ussdRequestObject3 = new UssdRequestObject("27821231240", "#AA1240", "100.45");
        CreateUssdResponse testOutput3 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject3);
        //perform tests
        assertEquals(truth.getSessionId(),testOutput3.getSessionId());
        assertEquals(truth.getMessage(),testOutput3.getMessage());


    }

    /**
     * Invalid test for new client in menu #3 send to Malawi
     */
    @Test
    public void handleCreateUssdRequestInvalidTest3MalawiEntry() {
        //truth
        CreateUssdResponse truth = new CreateUssdResponse();
        truth.setMessage("-10 is not a valid entry. How much money (in Rands) would you like to send to Malawi?");
        truth.setSessionId("#AA2240");
        //input
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27821231240", "#AA2240", "");
        CreateUssdResponse testOutput1 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);
        UssdRequestObject ussdRequestObject2 = new UssdRequestObject("27821231240", "#AA2240", "2");
        CreateUssdResponse testOutput2 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject2);
        UssdRequestObject ussdRequestObject3 = new UssdRequestObject("27821231240", "#AA2240", "-10");
        ValidationException exception = assertThrows(ValidationException.class,() -> {ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject3);});
        //perform tests
        assertEquals(exception.getSessionId(),truth.getSessionId());
        assertEquals(exception.getMessage(),truth.getMessage());


    }

    /**
     * Normal test for new client in menu #4 for Malawi
     */
    @Test
    public void handleCreateUssdRequestNormalTest4Entry() {
        //truth
        CreateUssdResponse truth = new CreateUssdResponse();
        truth.setMessage("Thank you for using Mama Money!");
        truth.setSessionId("#AA1241");
        //input
        UssdRequestObject ussdRequestObject = new UssdRequestObject("27821231241", "#AA1241", "");
        CreateUssdResponse testOutput1 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);
        UssdRequestObject ussdRequestObject2 = new UssdRequestObject("27821231241", "#AA1241", "2");
        CreateUssdResponse testOutput2 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject2);
        UssdRequestObject ussdRequestObject3 = new UssdRequestObject("27821231241", "#AA1241", "100.45");
        CreateUssdResponse testOutput3 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject3);
        UssdRequestObject ussdRequestObject4 = new UssdRequestObject("27821231241", "#AA1241", "1");
        CreateUssdResponse testOutput4 = ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject4);
        //perform tests
        assertEquals(truth.getSessionId(),testOutput4.getSessionId());
        assertEquals(truth.getMessage(),testOutput4.getMessage());


    }

    /**
     * nextMenuStage test to ensure transversal correct
     */
    @Test
    public void nextMenuStageTestNormal(){
        //truth
        MenuEntity truth = repository.findMenuEntity(3);
        //input
        MenuEntity inputMenu = repository.findMenuEntity(2);
        MenuEntity outputMenu = ussdServiceAdapter.nextMenuStage(inputMenu);
        //test
        assertEquals(outputMenu.getId(), truth.getId());

    }
    /**
     * TBC
     */



}
