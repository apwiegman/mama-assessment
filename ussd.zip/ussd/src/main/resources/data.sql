insert into menu_state (menu_stage,display_text,created_at,updated_at) values (0,'initialisation',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());
insert into menu_state (menu_stage,display_text,created_at,updated_at) values (1,'Welcome to Mama Money! Where would you like to send money to? %s',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());
insert into menu_state (menu_stage,display_text,created_at,updated_at) values (2,'How much money (in Rands) would you like to send to %s?',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());
insert into menu_state (menu_stage,display_text,created_at,updated_at) values (3,'Your person you are sending to will receive: %s',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());
insert into menu_state (menu_stage,display_text,created_at,updated_at) values (4,'Thank you for using Mama Money!',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());
insert into country (lookup_key, country_code, country_name,created_at,updated_at) values ('1','KES','Kenya',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());
insert into country (lookup_key, country_code, country_name,created_at,updated_at) values ('2','MWK','Malawi',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());