package com.mamamoney.ussd.domain.persistence.entities;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="prequote")
public class PrequoteEntity {
    //variables
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    @Column(name = "id", updatable = false, nullable = false)
    private long id;
    @Column(name="session_state_id", nullable = false)
    private long sessionStateId;
    @Column(name = "country_id", nullable = false)
    private long countryId;
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp createdAt;
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp updatedAt;

    //constructors
    public PrequoteEntity(long sessionStateId, long countryId) {
        this.sessionStateId = sessionStateId;
        this.countryId = countryId;
    }

    public PrequoteEntity() {
    }
    //methods
    public long getId() {
        return id;
    }

    public long getSessionStateId() {
        return sessionStateId;
    }

    public void setSessionStateId(long sessionStateId) {
        this.sessionStateId = sessionStateId;
    }

    public long getCountryId() {
        return countryId;
    }

    public void setCountryId(long countryId) {
        this.countryId = countryId;
    }
}
