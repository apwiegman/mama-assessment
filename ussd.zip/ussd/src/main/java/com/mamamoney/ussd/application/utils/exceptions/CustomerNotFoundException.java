package com.mamamoney.ussd.application.utils.exceptions;


public class CustomerNotFoundException extends RuntimeException {
    //constructor
    private String sessionId;

    /**
     * constructor for a customer not found exception
     * @param message
     * @param sessionId
     */
    public CustomerNotFoundException(String sessionId, String message) {
        super(message);
        this.sessionId = sessionId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }


}
