package com.mamamoney.ussd.infrastructure.persistence.repositories;

import com.mamamoney.ussd.domain.persistence.entities.UssdResponseEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UssdResponseRepository extends JpaRepository<UssdResponseEntity,Long> {
}
