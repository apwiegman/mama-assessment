package com.mamamoney.ussd.infrastructure.persistence.repositories;


import com.mamamoney.ussd.domain.persistence.entities.QuoteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


//String id - double check
@Repository
public interface QuoteRepository extends JpaRepository<QuoteEntity,Long> {
    Optional<QuoteEntity> findBySessionStateId(long sessionStateId);


}
