package com.mamamoney.ussd.infrastructure.dto.api.v1;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CreateUssdResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-02-05T08:34:38.234Z[GMT]")


public class CreateUssdResponse   {
  @JsonProperty("session_id")
  private String sessionId = null;

  @JsonProperty("message")
  private String message = null;

  public CreateUssdResponse sessionId(String sessionId) {
    this.sessionId = sessionId;
    return this;
  }

  /**
   * Session ID - Echoed from the request
   * @return sessionId
   **/
  @Schema(required = true, description = "Session ID - Echoed from the request")
      @NotNull

    public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public CreateUssdResponse message(String message) {
    this.message = message;
    return this;
  }

  /**
   * Message - response message from endpoint that will be returned to user
   * @return message
   **/
  @Schema(description = "Message - response message from endpoint that will be returned to user ")
  
    public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CreateUssdResponse createUssdResponse = (CreateUssdResponse) o;
    return Objects.equals(this.sessionId, createUssdResponse.sessionId) &&
        Objects.equals(this.message, createUssdResponse.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(sessionId, message);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CreateUssdResponse {\n");
    
    sb.append("    sessionId: ").append(toIndentedString(sessionId)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
