package com.mamamoney.ussd.domain.persistence.entities;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name="menu_state")
public class MenuEntity {
    //variables
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    @Column(name = "id", updatable = false, nullable = false)
    private long id;
    @Column(name="menu_stage", nullable = false)
    private int menuStage;
    @Column(name="display_text", nullable = false)
    private String displayText;
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp createdAt;
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp updatedAt;
    //method
    public MenuEntity(int menuStage, String displayText) {
        this.menuStage = menuStage;
        this.displayText = displayText;
    }

    public MenuEntity(){}
    //methods
    public long getId() {
        return id;
    }

    public int getMenuStage() {
        return menuStage;
    }

    public void setMenuStage(int menuStage) {
        this.menuStage = menuStage;
    }

    public String getDisplayText() {
        return displayText;
    }

    public void setDisplayText(String displayText) {
        this.displayText = displayText;
    }


}
