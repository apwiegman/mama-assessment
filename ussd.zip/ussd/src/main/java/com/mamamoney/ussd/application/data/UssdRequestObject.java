package com.mamamoney.ussd.application.data;

public class UssdRequestObject {
    private String msisdn;
    private String sessionId;
    private String userEntry;

    public UssdRequestObject(String msisdn, String sessionId, String userEntry) {
        this.msisdn = msisdn;
        this.sessionId = sessionId;
        this.userEntry = userEntry;
    }

    public String getUserEntry() {
        return userEntry;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getMsisdn() {
        return msisdn;
    }

}
