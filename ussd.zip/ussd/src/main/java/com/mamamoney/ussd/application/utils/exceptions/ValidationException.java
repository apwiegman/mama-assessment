package com.mamamoney.ussd.application.utils.exceptions;


public class ValidationException  extends RuntimeException {
    //constructor
    private String sessionId;

    /**
     * constructor for a validation exception. Supplied json properties did not align with expectation
     * @param message
     * @param sessionId
     */
    public ValidationException(String sessionId,String message) {
        super(message);
        this.sessionId = sessionId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }


}
