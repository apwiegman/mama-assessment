package com.mamamoney.ussd.application.utils.exceptions;

public class IncorrectMenuStageException extends RuntimeException{
    private String sessionId;

    /**
     * Exception class that
     * @param message
     * @param sessionId
     */
    public IncorrectMenuStageException(String message, String sessionId) {
        super(message);
        this.sessionId = sessionId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
}
