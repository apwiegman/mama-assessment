package com.mamamoney.ussd.application.service;


import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.domain.persistence.entities.UssdRequestEntity;

public interface UssdService {

    public UssdRequestEntity createUssdEntity(UssdRequestObject ussdRequestObject);

}
