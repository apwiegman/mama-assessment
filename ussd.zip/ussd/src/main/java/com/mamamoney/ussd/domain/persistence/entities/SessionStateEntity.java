package com.mamamoney.ussd.domain.persistence.entities;


import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="session_state")
public class SessionStateEntity {
    //variables
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    @Column(name = "id", updatable = false, nullable = false)
    private long id;
    @Column(name="customer_id", nullable = false)
    private long customerId;
    @Column(name="session_id", nullable = false)
    private String sessionId;
    @Column(name="menu_id", nullable = false)
    private long menuId;
    @Column(name = "complete", nullable = false)
    private int complete;
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp createdAt;
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp updatedAt;
    //constructors
    public SessionStateEntity() {
    }

    public SessionStateEntity(long customerId, String sessionId, long menuId, int complete) {
        this.customerId = customerId;
        this.sessionId = sessionId;
        this.menuId = menuId;
        this.complete = complete;
    }
    //methods

    public long getMenuId() {
        return menuId;
    }

    public void setMenuId(long menuId) {
        this.menuId = menuId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public long getId() {
        return id;
    }


    public long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public int getComplete() {
        return complete;
    }

    public void setComplete(int complete) {
        this.complete = complete;
    }


}
