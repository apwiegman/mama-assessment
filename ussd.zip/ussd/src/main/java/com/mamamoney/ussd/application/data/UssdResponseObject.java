package com.mamamoney.ussd.application.data;

public class UssdResponseObject {
    private String sessionId;
    private String message;

    public UssdResponseObject(String sessionId, String message) {
        this.sessionId = sessionId;
        this.message = message;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getMessage() {
        return message;
    }
}
