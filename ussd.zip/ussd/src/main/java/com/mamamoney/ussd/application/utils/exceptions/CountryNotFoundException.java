package com.mamamoney.ussd.application.utils.exceptions;


public class CountryNotFoundException extends RuntimeException {
    //constructor
    private String sessionId;

    /**
     * constructor for a country not found exception
     * @param message
     * @param sessionId
     */
    public CountryNotFoundException(String sessionId, String message) {
        super(message);
        this.sessionId = sessionId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }


}
