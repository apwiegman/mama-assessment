package com.mamamoney.ussd.domain.persistence.entities;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name="ussd_response")
public class UssdResponseEntity {
    //variables
    @Id
    @GeneratedValue
    @Column(name="id")
    private long id;
    @Column(name="session_id")
    private String sessionId;
    @Column(name="message")
    private String message;
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp createdAt;
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp updatedAt;
    //constructors
    public UssdResponseEntity(){

    }

    public UssdResponseEntity(String sessionId, String message) {
        this.sessionId = sessionId;
        this.message = message;
    }

    //methods
    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
