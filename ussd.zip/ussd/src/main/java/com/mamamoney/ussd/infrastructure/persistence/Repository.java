package com.mamamoney.ussd.infrastructure.persistence;

import com.mamamoney.ussd.application.utils.exceptions.CountryNotFoundException;
import com.mamamoney.ussd.application.utils.exceptions.CustomerNotFoundException;
import com.mamamoney.ussd.application.utils.exceptions.MenuNotFoundException;
import com.mamamoney.ussd.domain.persistence.entities.*;
import com.mamamoney.ussd.infrastructure.persistence.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Component
@Transactional
public class Repository {
    @Autowired
    private CountryRepository countryRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private MenuRepository menuRepository;
    @Autowired
    private PrequoteRepository prequoteRepository;
    @Autowired
    private QuoteRepository QuoteRepository;
    @Autowired
    private SessionStateRepository sessionStateRepository;
    @Autowired
    private UssdRequestRepository ussdRequestRepository;
    @Autowired
    private UssdResponseRepository ussdResponseRepository;
    @Autowired
    private QuoteRepository quoteRepository;

    // == Persist Methods == //

    public CustomerEntity persist(CustomerEntity customerEntity) {
        return customerRepository.save(customerEntity);
    }

    // public MenuEntity persist(MenuEntity menuEntity){ return menuRepository.save(menuEntity); } - should not be used

    public PrequoteEntity persist(PrequoteEntity prequoteEntity) {
        return prequoteRepository.save(prequoteEntity);
    }

    public QuoteEntity persist(QuoteEntity quoteEntity) {
        return quoteRepository.save(quoteEntity);
    }

    public SessionStateEntity persist(SessionStateEntity sessionStateEntity) {
        return sessionStateRepository.save(sessionStateEntity);
    }

    public UssdRequestEntity persist(UssdRequestEntity ussdRequestEntity) {
        return ussdRequestRepository.save(ussdRequestEntity);
    }

    public UssdResponseEntity persist(UssdResponseEntity ussdResponseEntity) {
        return ussdResponseRepository.save(ussdResponseEntity);
    }

    // == Find Methods == //

    public CustomerEntity findCustomerEntity(String msisdn) {
        //find customer
        Optional<CustomerEntity> customer = customerRepository.findByMsisdn(msisdn);
        //check if present
        if (customer.isPresent()) {
            return customer.get();
        } else {
            //throw error
            throw new CustomerNotFoundException(null, "Error encountered. Sorry for the inconvenience.");
        }
    }


    public CustomerEntity findCustomerEntity(long id) {
        //find customer
        Optional<CustomerEntity> customer = customerRepository.findById(id);
        //check if present
        if (customer.isPresent()) {
            return customer.get();
        } else {
            //throw error
            throw new CustomerNotFoundException(null, "Error encountered. Sorry for the inconvenience.");
        }
    }


    public CountryEntity findCountryEntity(String lookupKey) {
        Optional<CountryEntity> country = countryRepository.findByLookupKey(lookupKey.trim());
        if (country.isPresent()) {
            return country.get();
        } else {
            //throw exception
            throw new CountryNotFoundException(null, "Error encountered. Sorry for the inconvenience.");
        }
    }


    public CountryEntity findCountryEntity(long id) {
        Optional<CountryEntity> country = countryRepository.findById(id);
        if (country.isPresent()) {
            return country.get();
        } else {
            //throw exception
            throw new CountryNotFoundException(null, "Error encountered. Sorry for the inconvenience.");
        }
    }


    public List<CountryEntity> findAllCountryEntity() {
        return countryRepository.findAll();
    }

    public MenuEntity findMenuEntity(int menuStage) {
        //find menu
        Optional<MenuEntity> menu = menuRepository.findByMenuStage(menuStage);
        //check if present
        if (menu.isPresent()) {
            return menu.get();
        } else {
            //throw exception
            throw new MenuNotFoundException(null, "Error encountered. Sorry for the inconvenience.");
        }
    }

    public MenuEntity findMenuEntity(long id) {
        Optional<MenuEntity> menu = menuRepository.findById(id);
        if (menu.isPresent()) {
            return menu.get();
        } else {
            //throw exception
            throw new MenuNotFoundException(null, "Error encountered. Sorry for the inconvenience.");
        }
    }

    // == Extract Methods == //

    public Optional<CustomerEntity> extractCustomer(String msisdn) {
        //find customer
        return customerRepository.findByMsisdn(msisdn);
    }

    public Optional<MenuEntity> extractMenu(int menuStage) {
        //find menuStage
        return menuRepository.findByMenuStage(menuStage);
    }

    public Optional<PrequoteEntity> extractPrequote(SessionStateEntity sessionStateEntity) {
        //find prequote
        return prequoteRepository.findBySessionStateId(sessionStateEntity.getId());
    }

    public Optional<QuoteEntity> extractQuote(SessionStateEntity sessionStateEntity) {
        //find quote
        return quoteRepository.findBySessionStateId(sessionStateEntity.getId());
    }

    public Optional<SessionStateEntity> extractSessionState(long customerId, String sessionId) {
        //find session
        return sessionStateRepository.findBySessionIdAndCustomerIdAndComplete(sessionId, customerId, 0);
    }


}
