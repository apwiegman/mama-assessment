package com.mamamoney.ussd.infrastructure.api.ussd.v1;

import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.infrastructure.api.ussd.UssdServiceAdapter;
import com.mamamoney.ussd.infrastructure.api.ussd.UssdServiceMapper;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdRequest;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdResponse;
import com.mamamoney.ussd.infrastructure.validator.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/")
public class UssdController {

    @Autowired
    private UssdServiceAdapter ussdServiceAdapter;

    @Autowired
    private UssdServiceMapper ussdServiceMapper;

    @Autowired
    private Validator validator;

    @PostMapping("ussd")
    public ResponseEntity<CreateUssdResponse> createUssdRequest(
            @RequestBody CreateUssdRequest createUssdRequest
    ) {

        return ResponseEntity.ok(
                handleCreateUssdRequest(createUssdRequest)
        );
    }

    /**
     * maps the CreateUssdRequest received by endpoint a UssdRequestObject that is then passed to the UssdServiceAdapter that handles request
     * @param createUssdRequest
     * @return CreateUssdResponse
     */
    private CreateUssdResponse handleCreateUssdRequest(CreateUssdRequest createUssdRequest) {
        UssdRequestObject ussdRequestObject = ussdServiceMapper.mapCreateUssdRequest(createUssdRequest);
        return ussdServiceAdapter.handleCreateUssdRequest(ussdRequestObject);
    }

}
