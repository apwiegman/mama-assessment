package com.mamamoney.ussd.infrastructure.api.ussd;

import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.domain.persistence.entities.UssdRequestEntity;
import com.mamamoney.ussd.domain.persistence.entities.UssdResponseEntity;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdRequest;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdResponse;
import com.mamamoney.ussd.infrastructure.validator.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UssdServiceMapper {

    @Autowired
    private Validator validator;

    /**
     * performs input validation and then maps incoming createUssdRequest from dto to UssdRequestObject required in adapter
     * @param createUssdRequest is an object from the dto containing parameters provided in the request body
     * @return UssdRequestObject is a mapped object from the dto that has passed validation
     */
    public UssdRequestObject mapCreateUssdRequest(CreateUssdRequest createUssdRequest) {
        //validation
        validator.validateUssdRequest(createUssdRequest);
        //mapping
        return new UssdRequestObject(
                createUssdRequest.getMsisdn(),
                createUssdRequest.getSessionId(),
                createUssdRequest.getUserEntry());
    }

    /**
     * map UssdEntity to a CreateUssdResponse object that can be returned in controller
     * @param ussdResponseEntity is an object returned from the adapter after performing adapter logic
     * @return CreateUssdResponse is a dto object that is ready to be return in the controller as a ResponseEntity
     */
    public CreateUssdResponse mapUssdResponse(UssdResponseEntity ussdResponseEntity){
        CreateUssdResponse createUssdResponse = new CreateUssdResponse();
        //mapping
        createUssdResponse.setSessionId(ussdResponseEntity.getSessionId());
        createUssdResponse.setMessage(ussdResponseEntity.getMessage());
        return createUssdResponse;
    }






}
