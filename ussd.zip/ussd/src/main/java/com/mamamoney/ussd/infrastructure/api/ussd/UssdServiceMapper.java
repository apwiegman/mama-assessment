package com.mamamoney.ussd.infrastructure.api.ussd;

import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.domain.persistence.entities.UssdRequestEntity;
import com.mamamoney.ussd.domain.persistence.entities.UssdResponseEntity;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdRequest;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdResponse;
import com.mamamoney.ussd.infrastructure.validator.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UssdServiceMapper {

    @Autowired
    private Validator validator;

    /**
     * perfoems input validation and then maps incoming createUssdRequest from dto to UssdRequestObject required in adapter
     * @param createUssdRequest
     * @return UssdRequestObject
     */
    public UssdRequestObject mapCreateUssdRequest(CreateUssdRequest createUssdRequest) {
        //validation
        validator.validateUssdRequest(createUssdRequest);
        //mapping
        return new UssdRequestObject(
                createUssdRequest.getMsisdn(),
                createUssdRequest.getSessionId(),
                createUssdRequest.getUserEntry());
    }

    /**
     * map UssdEntity to a CreateUssdResponse object that can be returned in controller
     * @param ussdResponseEntity
     * @return
     */
    public CreateUssdResponse mapUssdResponse(UssdResponseEntity ussdResponseEntity){
        CreateUssdResponse createUssdResponse = new CreateUssdResponse();
        //mapping
        createUssdResponse.setSessionId(ussdResponseEntity.getSessionId());
        createUssdResponse.setMessage(ussdResponseEntity.getMessage());
        return createUssdResponse;
    }






}
