package com.mamamoney.ussd.application.service;

import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.domain.persistence.entities.UssdRequestEntity;
import org.springframework.stereotype.Service;


@Service
public class UssdServiceImpl {

    /**
     * Maps UssdRequestObejct to a UssdRequestEntity
     * @param ussdRequestObject
     * @return UssdRequestEntity
     */
    public UssdRequestEntity createUssdEntity(UssdRequestObject ussdRequestObject) {
        return new UssdRequestEntity(
                ussdRequestObject.getSessionId(),
                ussdRequestObject.getMsisdn(),
                ussdRequestObject.getUserEntry()
        );
    }


}
