package com.mamamoney.ussd.infrastructure.api.ussd;

import com.mamamoney.ussd.application.data.UssdRequestObject;
import com.mamamoney.ussd.application.service.UssdServiceImpl;
import com.mamamoney.ussd.application.utils.exceptions.IncorrectMenuStageException;
import com.mamamoney.ussd.application.utils.exceptions.ValidationException;
import com.mamamoney.ussd.domain.persistence.entities.*;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdResponse;
import com.mamamoney.ussd.infrastructure.persistence.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class UssdServiceAdapter {

    @Autowired
    private UssdServiceImpl ussdServiceImpl;

    @Autowired
    private Repository repository;

    @Autowired
    private UssdServiceMapper ussdServiceMapper;


    /**
     * Receives and processes the request for /api/v1/ussd endpoint after mapping and validation
     *
     * @param ussdRequestObject is a mapped object from the dto that has passed validation
     * @return CreateUssdResponse is an object returned from the adapter after performing adapter logic
     */
    public CreateUssdResponse handleCreateUssdRequest(UssdRequestObject ussdRequestObject) {

        //persist UssdRequestObject
        saveUssdRequest(ussdRequestObject);

        //find or create customer
        CustomerEntity customerEntity = findOrCreateCustomer(ussdRequestObject);

        //find or create sesionState
        SessionStateEntity currentSession = findOrCreateSessionState(customerEntity, ussdRequestObject);

        //update menu position - may return new sessionStateEntity
        SessionStateEntity sessionStateEntity = sessionStateManager(currentSession, ussdRequestObject);

        //menu logic
        UssdResponseEntity ussdResponseEntity = saveUssdResponse(menuLogic(sessionStateEntity, ussdRequestObject));


        return ussdServiceMapper.mapUssdResponse(ussdResponseEntity);
    }


    //Menu

    /**
     * return menu for next stage in the transversal if not already at Menu #4
     *
     * @param menuEntity is an object of type MenuEntity that contains information about a particular menu stage
     * @return MenuEntity contains information about a particular menu stage
     */
    public MenuEntity nextMenuStage(MenuEntity menuEntity) {
        MenuEntity newMenuEntity = null;
        if (menuEntity.getMenuStage() < 4) {
            newMenuEntity = findMenuEntity(menuEntity.getMenuStage() + 1);
        }
        return newMenuEntity;

    }

    /**
     * return menu for previous stage in menu transversal. This mehtod is called when a validation error is encountered
     *
     * @param menuEntity is an object of type MenuEntity that contains information about a particular menu stage
     * @return MenuEntity contains information about a particular menu stage
     */
    public MenuEntity previousMenuStage(MenuEntity menuEntity) {
        if (menuEntity.getMenuStage() > 0) {
            return findMenuEntity(menuEntity.getMenuStage() - 1);
        } else {
            return repository.findMenuEntity(0);
        }
    }

    /**
     * find a menu entity in transversal given Menu #
     *
     * @param menuStage is an integer that represents menu stage (#)
     * @return MenuEntity contains information about a particular menu stage
     */
    public MenuEntity findMenuEntity(int menuStage) {
        return repository.findMenuEntity(menuStage);
    }



    /**
     * manages transversal through menu stages and updating of SessionState object that tracks position
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param ussdRequestObject is a mapped object from the dto that has passed validation
     * @return SessionStateEntity that has been updated to reflect next menu position
     */
    public SessionStateEntity sessionStateManager(SessionStateEntity sessionStateEntity, UssdRequestObject ussdRequestObject) {
        //currentMenu
        MenuEntity currentMenuEntity = findMenuEntity(sessionStateEntity.getMenuId());
        MenuEntity nextMenuEntity = nextMenuStage(currentMenuEntity);
        //complete quote requests
        if (nextMenuEntity == null) {
            //move to new session state
            return sessionStateTransversal(sessionStateEntity, ussdRequestObject);
        }
        //save menu to current state
        sessionStateEntity.setMenuId(nextMenuEntity.getId());
        return saveSessionState(sessionStateEntity);
    }

    /**
     * sets current sessionState to complete and initialises a new sessionState for a customer
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param ussdRequestObject is a mapped object from the dto that has passed validation
     * @return new SessionStateEntity that has been initialised at start of menu
     */
    public SessionStateEntity sessionStateTransversal(SessionStateEntity sessionStateEntity, UssdRequestObject ussdRequestObject) {
        //set complete flag in current session
        sessionStateEntity.setComplete(1);
        saveSessionState(sessionStateEntity);
        //create new session
        CustomerEntity customerEntity = findCustomer(sessionStateEntity.getCustomerId());
        return findOrCreateSessionState(customerEntity, ussdRequestObject);
    }

    /**
     * Based on where customer is in the menu the desired actions are taken and response prepared
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param ussdRequestObject is a mapped object from the dto that has passed validation
     * @return UssdResponseEntity is an Entity that stores the reponse object before being passed to mappers and sent back to controller
     */
    public UssdResponseEntity menuLogic(SessionStateEntity sessionStateEntity, UssdRequestObject ussdRequestObject) {
        String message = "";
        switch (findMenuEntity(sessionStateEntity.getMenuId()).getMenuStage()) {
            case 2:
                //country send money to
                message = menu2Logic(sessionStateEntity, ussdRequestObject.getUserEntry());
                break;
            case 3:
                //quote
                message = menu3Logic(sessionStateEntity, ussdRequestObject.getUserEntry());
                break;
            case 4:
                //accept quote
                message = menu4Logic(sessionStateEntity, ussdRequestObject.getUserEntry());
                break;
            default:

                message = menu1Text(sessionStateEntity);
                break;
        }

        //ussdResponse
        return new UssdResponseEntity(sessionStateEntity.getSessionId(), message);


    }

    /**
     * Populates the text for the message response when customer is at menu #1
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @return String that represents text to be displayed
     */
    public String menu1Text(SessionStateEntity sessionStateEntity) {
        if (findMenuEntity(sessionStateEntity.getMenuId()).getMenuStage() == 1) {
            return String.format(findMenuEntity(sessionStateEntity.getMenuId()).getDisplayText(), menu1CountryList());
        } else {
            //throw exception
            throw new IncorrectMenuStageException("Error encountered. Sorry for the inconvenience.", sessionStateEntity.getSessionId());
        }

    }

    /**
     * Returns a correctly formatted list of countries to be added to message
     *
     * @return String of listed countries
     */
    public String menu1CountryList() {
        String holder = "";
        List<CountryEntity> countries = findAllCountry();
        int counter = 1;
        for (CountryEntity countryEntity : countries) {
            holder = holder + "\n" + counter + ") " + countryEntity.getName();
            counter++;
        }
        return holder;
    }

    /**
     * performs logical steps associated with Menu #2 and prepares response
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param userEntry is the userEntry string provided by a user
     * @return String response to be displayed for Menu #2
     */
    public String menu2Logic(SessionStateEntity sessionStateEntity, String userEntry) {
        //validate text input
        if (!menu2InputValidation(userEntry)) {
            //roll back to previous step
            sessionStateEntity = rollBackSessionStateEntity(sessionStateEntity);
            throw new ValidationException(sessionStateEntity.getSessionId(), userEntry + " is not a valid entry. " + menu1Text(sessionStateEntity));
        }
        //create new prequote
        PrequoteEntity prequoteEntity = findOrCreatePrequote(sessionStateEntity, userEntry);

        //update ussdResponse
        return menu2Text(sessionStateEntity, prequoteEntity);

    }

    /**
     * validates that the userEntry for Menu #2 is valid
     *
     * @param userEntry is the userEntry string provided by a user
     * @return boolean representing whether validation passed or failed
     */
    public boolean menu2InputValidation(String userEntry) {
        if(userEntry == null){
            return false;
        } else if ( userEntry.trim().equals("1") || userEntry.trim().equals("2")) {
            return true;
        }else{
            return false;
        }

    }

    /**
     * Populates the text for the message response when customer is at menu #2
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param prequoteEntity is an Entity that contains information about decisions a customer made leading up to issuing a quote
     * @return String response to be displayed for Menu #2
     */
    public String menu2Text(SessionStateEntity sessionStateEntity, PrequoteEntity prequoteEntity) {
        if (findMenuEntity(sessionStateEntity.getMenuId()).getMenuStage() == 2) {
            return String.format(findMenuEntity(sessionStateEntity.getMenuId()).getDisplayText(), findCountry(prequoteEntity.getCountryId()).getName());
        } else {
            throw new IncorrectMenuStageException("Error encountered. Sorry for the inconvenience.", sessionStateEntity.getSessionId());
        }
    }

    /**
     * performs logical steps associated with Menu #3 and prepares response
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param userEntry is the userEntry string provided by a user
     * @return String response to be displayed for Menu #3
     */
    public String menu3Logic(SessionStateEntity sessionStateEntity, String userEntry) {
        //retrieve prequote
        PrequoteEntity prequoteEntity = findOrCreatePrequote(sessionStateEntity, null);
        //validate text input
        if (!menu3InputValidation(userEntry)) {
            sessionStateEntity = rollBackSessionStateEntity(sessionStateEntity);
            throw new ValidationException(sessionStateEntity.getSessionId(), userEntry + " is not a valid entry. " + menu2Text(sessionStateEntity, prequoteEntity));
        }
        //check amount less than 1 million otherwise possibly in breach of single discretionary allowance
        if (menu3InputValidationAmount(userEntry)) {
            sessionStateEntity = rollBackSessionStateEntity(sessionStateEntity);
            throw new ValidationException(sessionStateEntity.getSessionId(), userEntry + " is more than limit of R1 million. " + menu2Text(sessionStateEntity, prequoteEntity));
        }
        //create new quote
        QuoteEntity quoteEntity = findOrCreateQuote(sessionStateEntity, prequoteEntity, userEntry);

        //update response string
        return menu3Text(sessionStateEntity, prequoteEntity, quoteEntity);
    }

    /**
     * validates the userEntry for Menu #3 requirements of being real and non-negative
     *
     * @param userEntry is the userEntry string provided by a user
     * @return boolean indicator of whether user input passed validation
     */
    public boolean menu3InputValidation(String userEntry) {
        //check 1 - validate not null
        if(userEntry == null){
            return false;
        }
        //check 2 -  validate real number
        if (menu3InputValidationValidNumber(userEntry)) {
            return false;
        }
        //check 3 - validate non-negative
        if (menu3InputValidationNegative(userEntry)) {
            return false;
        }

        return true;
    }

    /**
     * validates that userEntry is a real number
     *
     * @param userEntry is the userEntry string provided by a user
     * @return boolean value representing whether user entry is a real number
     */
    public boolean menu3InputValidationValidNumber(String userEntry) {
        try {
            Double.parseDouble(userEntry.trim());
        } catch (Exception e) {
            return true;
        }
        return false;
    }

    /**
     * validates that userEntry is non-negative
     *
     * @param userEntry is the userEntry string provided by a user
     * @return  boolean value representing whether user entry is a non-negative number
     */
    public boolean menu3InputValidationNegative(String userEntry) {
        if (Double.parseDouble(userEntry.trim()) < 0) {
            return true;
        }
        return false;
    }

    public boolean menu3InputValidationAmount(String userEntry) {
        if (Double.parseDouble(userEntry.trim()) > 1000000) {
            return true;
        }
        return false;
    }

    /**
     * performs currency conversion given then baseCurrency and baseAmount and foreignCurrency
     *
     * @param baseAmount is the supplied amount in baseCurrency
     * @param baseCurrency is the base currency for conversion
     * @param foreignCurrency is the foreign currency to be converted to
     * @return double amount is return of the converted foreignCurrency amount
     */
    public double currencyConversion(double baseAmount, String baseCurrency, String foreignCurrency) {
        //drop anything less than cents
        baseAmount = (double) Math.round(baseAmount*100)/100;
        //do conversion
        if (foreignCurrency.equals("KES")) {
            return (double) Math.round(baseAmount * 6.1 * 100.0) / 100.0;
        }
        return Math.round(baseAmount * 42.5 * 100.0) / 100.0;
    }

    /**
     * populates the text for the message response when customer is at menu #3
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param prequoteEntity is an Entity that contains information about decisions a customer made leading up to issuing a quote
     * @param quoteEntity is an Entity that contains information about a customer quote
     * @return String response to be displayed for Menu #3
     */
    public String menu3Text(SessionStateEntity sessionStateEntity, PrequoteEntity prequoteEntity, QuoteEntity quoteEntity) {
        if (findMenuEntity(sessionStateEntity.getMenuId()).getMenuStage() == 3) {
            return String.format(findMenuEntity(sessionStateEntity.getMenuId()).getDisplayText(), findCountry(prequoteEntity.getCountryId()).getCountryCode() + " " + quoteEntity.getForeignAmount() + "\n1) OK");
        } else {
            throw new IncorrectMenuStageException("Error encountered. Sorry for the inconvenience.", sessionStateEntity.getSessionId());
        }
    }

    /**
     * performs logical steps associated with Menu #4 and prepares response
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param userEntry is the userEntry string provided by a user
     * @return String
     */
    public String menu4Logic(SessionStateEntity sessionStateEntity, String userEntry) {
        //retrieve prequote
        PrequoteEntity prequoteEntity = findOrCreatePrequote(sessionStateEntity, null);
        //return quote
        QuoteEntity quoteEntity = findOrCreateQuote(sessionStateEntity, prequoteEntity, null);
        //validate text input
        if (!menu4InputValidation(userEntry)) {
            sessionStateEntity = rollBackSessionStateEntity(sessionStateEntity);
            throw new ValidationException(sessionStateEntity.getSessionId(), userEntry + " is not a valid entry. " + menu3Text(sessionStateEntity, prequoteEntity, quoteEntity));
        }
        //updateQuote
        QuoteEntity updatedQuoteEntity = completeQuote(quoteEntity);
        //update session
        sessionStateEntity.setComplete(1);
        SessionStateEntity newSessionStateEntity = saveSessionState(sessionStateEntity);
        //create output string
        return menu4Text(sessionStateEntity);

    }

    /**
     * validate userEntry input supplied for Menu #4
     *
     * @param userEntry is the userEntry string provided by a user
     * @return
     */
    public boolean menu4InputValidation(String userEntry) {
        if(userEntry == null){
            return false;
        }else if ( userEntry.trim().equals("1")) {
            return true;
        }else{
            return false;
        }
    }

    /**
     * populates message associated with Menu #4
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @return String response to be displayed for Menu #4
     */
    public String menu4Text(SessionStateEntity sessionStateEntity) {
        if (findMenuEntity(sessionStateEntity.getMenuId()).getMenuStage() == 4) {
            return findMenuEntity(sessionStateEntity.getMenuId()).getDisplayText();
        } else {
            throw new IncorrectMenuStageException("Error encountered. Sorry for the inconvenience.", sessionStateEntity.getSessionId());
        }
    }

    //Prequote

    /**
     * find an existing Prequote entity or create a new Prequote entity if does not exist
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param userEntry is the userEntry string provided by a user
     * @return PrequoteEntity
     */
    public PrequoteEntity findOrCreatePrequote(SessionStateEntity sessionStateEntity, String userEntry) {
        Optional<PrequoteEntity> prequote = repository.extractPrequote(sessionStateEntity);
        if (prequote.isPresent()) {
            return prequote.get();
        } else {
            //get country
            CountryEntity countryEntity = findCountry(userEntry);
            PrequoteEntity newPrequoteEntity = new PrequoteEntity(sessionStateEntity.getId(), countryEntity.getId());
            return savePrequote(newPrequoteEntity);
        }
    }

    //Quote

    /**
     * find an existing Quote entity or create a new Quote entity if does not exist
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @param prequoteEntity is an Entity that contains information about decisions a customer made leading up to issuing a quote
     * @param userEntry is the userEntry string provided by a user
     * @return QuoteEntity contains information about a customer quote
     */
    public QuoteEntity findOrCreateQuote(SessionStateEntity sessionStateEntity, PrequoteEntity prequoteEntity, String userEntry) {
        Optional<QuoteEntity> quote = repository.extractQuote(sessionStateEntity);
        if (quote.isPresent()) {
            return quote.get();
        } else {
            String baseCurrency = "ZAR";
            double baseAmount = Double.parseDouble(userEntry.trim());
            String foreignCurrency = findCountry(prequoteEntity.getCountryId()).getCountryCode();
            double foreignAmount = currencyConversion(baseAmount, baseCurrency, foreignCurrency);

            QuoteEntity newQuoteEntity = new QuoteEntity(sessionStateEntity.getId(), baseCurrency, baseAmount, foreignCurrency, foreignAmount, 0);
            return saveQuote(newQuoteEntity);
        }

    }

    /**
     * updates quote to reflect as accepted
     *
     * @param quoteEntity is an Entity that contains information about a customer quote
     * @return QuoteEntity contains information about a customer quote
     */
    public QuoteEntity completeQuote(QuoteEntity quoteEntity) {
        quoteEntity.setAccepted(1);
        return saveQuote(quoteEntity);
    }


    //SessionState

    /**
     * find an existing SessionState entity or create a new SessionState entity if not exist
     *
     * @param customerEntity is an Entity that contains information about a customer
     * @param ussdRequestObject is an object that contains information about the ussd request post mapping and validation
     * @return SessionStateEntity that tracks a customers progress as they transverse menu stages during a particular session
     */
    public SessionStateEntity findOrCreateSessionState(CustomerEntity customerEntity, UssdRequestObject ussdRequestObject) {
        return getSessionState(customerEntity, ussdRequestObject.getSessionId());
    }

    /**
     * find an existing SessionState entity or create a new SessionState entity if not exist
     *
     * @param customerEntity is an Entity that contains information about a customer
     * @param sessionId is string value that represents the unique session identifier
     * @return SessionStateEntity that tracks a customers progress as they transverse menu stages during a particular session
     */
    public SessionStateEntity getSessionState(CustomerEntity customerEntity, String sessionId) {
        Optional<SessionStateEntity> sessionState = repository.extractSessionState(customerEntity.getId(), sessionId);
        if (sessionState.isPresent()) {
            // return sessionState
            return sessionState.get();
        } else {
            return createSessionState(customerEntity, sessionId);
        }
    }

    /**
     * RollBack SessionState to reflect previous MenuStage
     *
     * @param sessionStateEntity is an Entity that tracks a customers progress as they transverse menu stages during a particular session
     * @return SessionStateEntity that tracks a customers progress as they transverse menu stages during a particular session
     */
    public SessionStateEntity rollBackSessionStateEntity(SessionStateEntity sessionStateEntity) {
        //get previous menu
        MenuEntity newMenuEntity = previousMenuStage(findMenuEntity(sessionStateEntity.getMenuId()));
        //update sessionState
        sessionStateEntity.setMenuId(newMenuEntity.getId());
        return saveSessionState(sessionStateEntity);
    }

    // == Private Methods == //

    //Country

    /**
     * find a specific Country given a menu entry that acts as a key
     *
     * @param lookupKey is a string value that can be used to map a countries position in menu text to a CountryEntity
     * @return CountryEntity is on object that contains information pertaining to a certain country
     */
    private CountryEntity findCountry(String lookupKey) {
        return repository.findCountryEntity(lookupKey.trim());
    }

    /**
     * find a Country given primary key
     *
     * @param id is long value representing primary key used to find a specific country
     * @return CountryEntity  is on object that contains information pertaining to a certain country
     */
    private CountryEntity findCountry(long id) {
        return repository.findCountryEntity(id);
    }

    /**
     * find a list of all Country entities
     *
     * @return List<CountryEntity> is a list of all countries
     */
    private List<CountryEntity> findAllCountry() {
        return repository.findAllCountryEntity();
    }

    //Customer

    /**
     * finds an existing customer or creates a new customer entity
     *
     * @param ussdRequestObject is an object that contains information about the ussd request post mapping and validation
     * @return CustomerEntity is an Entity that contains information about a customer
     */
    private CustomerEntity findOrCreateCustomer(UssdRequestObject ussdRequestObject) {
        return findCustomer(ussdRequestObject.getMsisdn());
    }

    /**
     * given an msisdn either need to return exisitng customer or create a new customer and persist
     *
     * @param msisdn is a string value used to find an existing customer
     * @return CustomerEntity is an Entity that contains information about a customer
     */
    private CustomerEntity findCustomer(String msisdn) {
        Optional<CustomerEntity> customer = repository.extractCustomer(msisdn);
        if (customer.isPresent()) {
            return customer.get();
        } else {
            //create and persist new customer
            CustomerEntity newCustomerEntity = new CustomerEntity(msisdn);
            return saveCustomer(newCustomerEntity);
        }
    }

    /**
     * finds a CustomerEntity given a primary key
     * @param id is a long value that represents primary key associated with customer during persistence
     * @return CustomerEntity contains information about a customer
     */
    private CustomerEntity findCustomer(long id) {
        return repository.findCustomerEntity(id);
    }

    /**
     * persist customer entity
     *
     * @param customerEntity is an Entity that contains information about a customer
     * @return CustomerEntity contains information about a customer
     */
    private CustomerEntity saveCustomer(CustomerEntity customerEntity) {
        return repository.persist(customerEntity);
    }

    //Menu

    /**
     * find a menu entity given primary key
     *
     * @param id is a long value that presents primary key associated with a persisted menu object
     * @return MenuEntity that contains information about a Menu object
     */
    private MenuEntity findMenuEntity(long id) {
        return repository.findMenuEntity(id);
    }

    //Prequote

    /**
     * persist PrequoteEntity to database
     *
     * @param prequoteEntity is an Entity that contains information about decisions a customer made leading up to issuing a quote
     * @return PrequoteEntity contains information about decisions a customer made leading up to issuing a quote
     */
    private PrequoteEntity savePrequote(PrequoteEntity prequoteEntity) {
        return repository.persist(prequoteEntity);
    }

    //Quote

    /**
     * persist Quote entity to a database
     *
     * @param quoteEntity is an Entity that contains information about a customer quote
     * @return QuoteEntity that contains updated information about a customer quote
     */
    public QuoteEntity saveQuote(QuoteEntity quoteEntity) {
        return repository.persist(quoteEntity);
    }

    //SessionState

    /**
     * create and initialise new SessionState entity to track where a client is in menu for a specific session
     *
     * @param customerEntity is an Entity that contains information about a customer
     * @param sessionId is a string value that represents unique identifier for a customer session
     * @return SessionStateEntity is an object that tracks a customers progress as they transverse menu stages during a particular session
     */
    private SessionStateEntity createSessionState(CustomerEntity customerEntity, String sessionId) {
        //create new menu in state = 0 (initialisation)
        MenuEntity menuEntity = findMenuEntity(0);
        //create and persist new sessionState
        SessionStateEntity newSessionStateEntity = new SessionStateEntity(customerEntity.getId(), sessionId, menuEntity.getId(), 0);
        return saveSessionState(newSessionStateEntity);
    }

    /**
     * persist SessionStateEntity to database
     *
     * @param sessionStateEntity is an object that tracks a customers progress as they transverse menu stages during a particular session
     * @return SessionStateEntity is a persisted version of object supplied
     */
    private SessionStateEntity saveSessionState(SessionStateEntity sessionStateEntity) {
        return repository.persist(sessionStateEntity);
    }

    //UssdRequest

    /**
     * persist UssdRequest to database
     *
     * @param ussdRequestObject is an object that contains information about the ussd request post mapping and validation
     * @return UssdRequestEntity  is a persisted version of object supplied
     */
    private UssdRequestEntity saveUssdRequest(UssdRequestObject ussdRequestObject) {
        return repository.persist(ussdServiceImpl.createUssdEntity(ussdRequestObject));
    }

    //UssdResponse

    /**
     * persist a UssdResponseEntity to database
     *
     * @param ussdResponseEntity is the object that represents the ussd response before mapping
     * @return UssdResponseEntity  is a persisted version of object supplied
     */
    private UssdResponseEntity saveUssdResponse(UssdResponseEntity ussdResponseEntity) {
        return repository.persist(ussdResponseEntity);
    }

}
