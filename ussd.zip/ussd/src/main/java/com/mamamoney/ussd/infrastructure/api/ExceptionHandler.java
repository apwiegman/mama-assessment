package com.mamamoney.ussd.infrastructure.api;


import com.mamamoney.ussd.application.utils.exceptions.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class ExceptionHandler {

    /**
     * creates error response for user entry exceptions
     * @param validationException
     * @return ResponseEntity
     */
    @org.springframework.web.bind.annotation.ExceptionHandler
    public ResponseEntity<ExceptionResponse> validationException(ValidationException validationException) {
        ExceptionResponse exceptionResponse = handleValidationException(validationException);
        return new ResponseEntity<>(
                exceptionResponse,
                HttpStatus.BAD_REQUEST
        );

    }
    /**
     * creates error response for validation exceptions
     * @param validationException
     * @return ResponseEntity
     */
    private ExceptionResponse handleValidationException(ValidationException validationException) {
        ExceptionResponse error = new ExceptionResponse();
        error.setMessage(validationException.getMessage());
        error.setSessionId(validationException.getSessionId());
        return error;
    }

    /**
     * Error handler for exceptions thrown in repository as result of customers not being present in database
     * @param customerNotFoundException
     * @return ResponseEntity
     */
    @org.springframework.web.bind.annotation.ExceptionHandler
    public ResponseEntity<ExceptionResponse> customerNotFoundException(CustomerNotFoundException customerNotFoundException) {
        ExceptionResponse exceptionResponse = handleCustomerNotFoundException(customerNotFoundException);
        return new ResponseEntity<>(
                exceptionResponse,
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    /**
     * creates error response for customer not found exception
     * @param customerNotFoundException
     * @return ExceptionResponse
     */
    private ExceptionResponse handleCustomerNotFoundException(CustomerNotFoundException customerNotFoundException) {
        ExceptionResponse error = new ExceptionResponse();
        error.setMessage(customerNotFoundException.getMessage());
        error.setSessionId(customerNotFoundException.getSessionId());
        return error;
    }

    /**
     * Error handler for exceptions thrown in repository as result of country not being present in database
     * @param countryNotFoundException
     * @return ResponseEntity
     */
    @org.springframework.web.bind.annotation.ExceptionHandler
    public ResponseEntity<ExceptionResponse> countryNotFoundException(CountryNotFoundException countryNotFoundException) {
        ExceptionResponse exceptionResponse = handleCountryNotFoundException(countryNotFoundException);
        return new ResponseEntity<>(
                exceptionResponse,
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    /**
     * creates error response for country not found exception
     * @param countryNotFoundException
     * @return ExceptionResponse
     */
    private ExceptionResponse handleCountryNotFoundException(CountryNotFoundException countryNotFoundException) {
        ExceptionResponse error = new ExceptionResponse();
        error.setMessage(countryNotFoundException.getMessage());
        error.setSessionId(countryNotFoundException.getSessionId());
        return error;
    }

    /**
     * Error handler for exceptions thrown in repository as result of menu not being present in database
     * @param menuNotFoundException
     * @return ResponseEntity
     */
    @org.springframework.web.bind.annotation.ExceptionHandler
    public ResponseEntity<ExceptionResponse> menuNotFoundException(MenuNotFoundException menuNotFoundException) {
        ExceptionResponse exceptionResponse = handleMenuNotFoundException(menuNotFoundException);
        return new ResponseEntity<>(
                exceptionResponse,
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    /**
     * creates error response for menu not found exception
     * @param menuNotFoundException
     * @return ExceptionResponse
     */
    private ExceptionResponse handleMenuNotFoundException(MenuNotFoundException menuNotFoundException) {
        ExceptionResponse error = new ExceptionResponse();
        error.setMessage(menuNotFoundException.getMessage());
        error.setSessionId(menuNotFoundException.getSessionId());
        return error;
    }


    /**
     * Error handler for exceptions thrown for menu stage not aligning with the expected menu stage
     * @param incorrectMenuStageException
     * @return ResponseEntity
     */
    @org.springframework.web.bind.annotation.ExceptionHandler
    public ResponseEntity<ExceptionResponse> incorrectMenuStageException(IncorrectMenuStageException incorrectMenuStageException) {
        ExceptionResponse exceptionResponse = handleMenuNotFoundException(incorrectMenuStageException);
        return new ResponseEntity<>(
                exceptionResponse,
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    /**
     * creates error response for incorrect menu stage exception
     * @param incorrectMenuStageException
     * @return ExceptionResponse
     */
    private ExceptionResponse handleMenuNotFoundException(IncorrectMenuStageException incorrectMenuStageException) {
        ExceptionResponse error = new ExceptionResponse();
        error.setMessage(incorrectMenuStageException.getMessage());
        error.setSessionId(incorrectMenuStageException.getSessionId());
        return error;
    }



}
