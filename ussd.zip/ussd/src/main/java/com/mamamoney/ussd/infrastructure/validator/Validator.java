package com.mamamoney.ussd.infrastructure.validator;

import com.mamamoney.ussd.application.utils.exceptions.ValidationException;
import com.mamamoney.ussd.infrastructure.dto.api.v1.CreateUssdRequest;
import org.springframework.stereotype.Component;


@Component
public class Validator {

    private final int MIN_LENGTH_MSISDN = 6;
    private final int MAX_LENGTH_MSISDN = 18;
    private final int MIN_LENGTH_SESSION_ID = 6;
    private final int MAX_LENGTH_SESSION_ID = 40;
    private final int MAX_LENGTH_USER_ENTRY = 9;

    /**
     * Runs validation checks against inputs provided in the CreateUssdRequestObject
     * @param createUssdRequest
     */
    public void validateUssdRequest(CreateUssdRequest createUssdRequest) {
        //msisdn not null
        ValidatorObject check01 = validateMsisdnNotNull(createUssdRequest.getMsisdn());
        if (!check01.isValid) {
            throw new ValidationException(createUssdRequest.getSessionId(), check01.message);
        }
        //msisdn type
        ValidatorObject check02 = validateMsisdnType(createUssdRequest.getMsisdn());
        if(!check02.isValid) {
            throw new ValidationException(createUssdRequest.getSessionId(), check02.message);
        }
        //msisdn not empty
        ValidatorObject check03 = validateMsisdnNotEmpty(createUssdRequest.getMsisdn());
        if (!check03.isValid) {
            throw new ValidationException(createUssdRequest.getSessionId(), check03.message);
        }
        //msisdn length
        ValidatorObject check04 = validateMsisdnLength(createUssdRequest.getMsisdn());
        if (!check04.isValid) {
            throw new ValidationException(createUssdRequest.getSessionId(), check04.message);
        }
        //sessionId null
        ValidatorObject check05 = validateSessionIdNotNull(createUssdRequest.getSessionId());
        if(!check05.isValid) {
            throw new ValidationException(createUssdRequest.getSessionId(), check05.message);
        }
        //sessionId type
        ValidatorObject check06 = validateSessionIdType(createUssdRequest.getSessionId());
        if(!check06.isValid) {
            throw new ValidationException(createUssdRequest.getSessionId(), check06.message);
        }
        //sessionId not empty
        ValidatorObject check07 = validateSessionIdNotEmpty(createUssdRequest.getSessionId());
        if(!check07.isValid) {
            throw new ValidationException(createUssdRequest.getSessionId(), check07.message);
        }
        //sessionId length
        ValidatorObject check08 = validateSessionIdLength(createUssdRequest.getSessionId());
        if(!check08.isValid) {
            throw new ValidationException(createUssdRequest.getSessionId(), check08.message);
        }


    }

    /**
     * check supplied msisdn is not null
     * @param msisdn
     * @return ValidatorObject
     */
    private ValidatorObject validateMsisdnNotNull(String msisdn) {
        if (msisdn == null  ) {
            return new ValidatorObject(false, "msisdn is a required field");
        } else {
            return new ValidatorObject(true);
        }
    }
    /**
     * check supplied msisdn is not empty
     * @param msisdn
     * @return ValidatorObject
     */
    private ValidatorObject validateMsisdnNotEmpty(String msisdn) {
        if (msisdn.trim().equals("")) {
            return new ValidatorObject(false, "invalid msisdn - should be between "+ MIN_LENGTH_MSISDN +" and "+ MAX_LENGTH_MSISDN+" characters");
        } else {
            return new ValidatorObject(true);
        }
    }
    /**
     * check supplied msisdn is of required length
     * @param msisdn
     * @return ValidatorObject
     */
    private ValidatorObject validateMsisdnLength(String msisdn) {
        if (msisdn.length() < MIN_LENGTH_MSISDN || msisdn.length() > MAX_LENGTH_MSISDN) {
            return new ValidatorObject(false, "invalid msisdn - should be between "+ MIN_LENGTH_MSISDN +" and "+ MAX_LENGTH_MSISDN+" characters");
        } else {
            return new ValidatorObject(true);
        }
    }
    /**
     * check supplied msisdn is correct type
     * @param msisdn
     * @return ValidatorObject
     */
    private ValidatorObject validateMsisdnType(String msisdn) {
        if (! (msisdn instanceof String)) {
            return new ValidatorObject(false, "invalid msisdn - mandatory string");
        } else {
            return new ValidatorObject(true);
        }
    }
    /**
     * check supplied sessionId is not null
     * @param sessionId
     * @return ValidatorObject
     */
    private ValidatorObject validateSessionIdNotNull(String sessionId) {
        if (sessionId == null) {
            return new ValidatorObject(false, "sessionId is a required field");
        } else {
            return new ValidatorObject(true);
        }
    }
    /**
     * check supplied sessionId is not empty
     * @param sessionId
     * @return ValidatorObject
     */
    private ValidatorObject validateSessionIdNotEmpty(String sessionId) {
        if (sessionId.trim().equals("")) {
            return new ValidatorObject(false, "invalid sessionId - should be between "+ MIN_LENGTH_SESSION_ID +" and "+ MAX_LENGTH_SESSION_ID+" characters");
        } else {
            return new ValidatorObject(true);
        }
    }
    /**
     * check supplied sessionId is of required length
     * @param sessionId
     * @return ValidatorObject
     */
    private ValidatorObject validateSessionIdLength(String sessionId) {
        if (sessionId.length() < MIN_LENGTH_SESSION_ID || sessionId.length() > MAX_LENGTH_SESSION_ID) {
            return new ValidatorObject(false, "invalid sessionId - should be between "+ MIN_LENGTH_SESSION_ID +" and "+ MAX_LENGTH_SESSION_ID+" characters");
        } else {
            return new ValidatorObject(true);
        }
    }
    /**
     * check supplied sessionId is of the correct type
     * @param sessionId
     * @return ValidatorObject
     */
    private ValidatorObject validateSessionIdType(String sessionId) {
        if (! (sessionId instanceof String)) {
            return new ValidatorObject(false, "invalid sessionId - mandatory string");
        } else {
            return new ValidatorObject(true);
        }
    }


    class ValidatorObject {

        private boolean isValid;
        private String message;

        public ValidatorObject(boolean isValid, String message) {
            this.isValid = isValid;
            this.message = message;
        }

        public ValidatorObject(boolean isValid) {
            this.isValid = isValid;
            this.message = null;
        }

        public boolean isValid() {
            return isValid;
        }

        public String getMessage() {
            return message;
        }
    }

}
