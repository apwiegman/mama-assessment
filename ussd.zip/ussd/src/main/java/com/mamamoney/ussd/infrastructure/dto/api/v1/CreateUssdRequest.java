package com.mamamoney.ussd.infrastructure.dto.api.v1;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CreateUssdRequest
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-02-05T08:34:38.234Z[GMT]")


public class CreateUssdRequest {
    @JsonProperty("sessionId")
    private String sessionId = null;

    @JsonProperty("msisdn")
    private String msisdn = null;

    @JsonProperty("userEntry")
    private String userEntry = null;

    public CreateUssdRequest sessionId(String sessionId) {
        this.sessionId = sessionId;
        return this;
    }

    /**
     * Session ID - A session identifier assigned by the WASP, it
     * will be consistent for a user across multiple
     * interactions.
     *
     * @return sessionId
     **/
    @Schema(required = true, description = "Session ID - session identifier assigned by the WASP")
    @NotNull

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public CreateUssdRequest msisdn(String msisdn) {
        this.msisdn = msisdn;
        return this;
    }

    /**
     * MSISDN - represents a cell phone number and can be
     * considered unique per user
     *
     * @return msisdn
     **/
    @Schema(required = true, description = "MSISDN - represents a cell phone number and can be\n" +
            "considered unique per user")
    @NotNull

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public CreateUssdRequest userEntry(String userEntry) {
        this.userEntry = userEntry;
        return this;
    }

    /**
     * userEntry - user’s text/number entry
     * from their cellphone
     *
     * @return userEntry
     **/
    @Schema(description = "userEntry - user’s text/number entry\n" +
            "from their cellphone")

    public String getUserEntry() {
        return userEntry;
    }

    public void setUserEntry(String userEntry) {
        this.userEntry = userEntry;
    }


    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CreateUssdRequest createUssdRequest = (CreateUssdRequest) o;
        return Objects.equals(this.sessionId, createUssdRequest.sessionId) &&
                Objects.equals(this.msisdn, createUssdRequest.msisdn) &&
                Objects.equals(this.userEntry, createUssdRequest.userEntry);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sessionId, msisdn, userEntry);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class CreateUssdRequest {\n");

        sb.append("    sessionId: ").append(toIndentedString(sessionId)).append("\n");
        sb.append("    msisdn: ").append(toIndentedString(msisdn)).append("\n");
        sb.append("    userEntry: ").append(toIndentedString(userEntry)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
