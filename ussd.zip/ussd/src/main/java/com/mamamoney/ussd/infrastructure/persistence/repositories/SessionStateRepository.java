package com.mamamoney.ussd.infrastructure.persistence.repositories;

import com.mamamoney.ussd.domain.persistence.entities.CustomerEntity;
import com.mamamoney.ussd.domain.persistence.entities.SessionStateEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SessionStateRepository extends JpaRepository<SessionStateEntity,Long> {
    Optional<SessionStateEntity> findBySessionId(String sessionId);
    Optional<SessionStateEntity> findBySessionIdAndCustomerIdAndComplete(String sessionId, long customerId, int complete);
}
