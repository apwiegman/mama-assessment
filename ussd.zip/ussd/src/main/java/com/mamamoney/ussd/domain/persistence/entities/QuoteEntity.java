package com.mamamoney.ussd.domain.persistence.entities;


import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;


@Entity
@Table(name="quotes")
public class QuoteEntity {
    //variables
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    @Column(name = "id", updatable = false, nullable = false)
    private long id;
    @Column(name="session_state_id", nullable = false)
    private long sessionStateId;
    @Column(name="base_currency", nullable = false)
    private String baseCurrency;
    @Column(name="base_amount", nullable = false)
    private double baseAmount;
    @Column(name="foreign_currency", nullable = false)
    private String foreignCurrency;
    @Column(name="foreign_amount", nullable = false)
    private double foreignAmount;
    @Column(name="accepted", nullable = false)
    private int accepted;
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp createdAt;
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false, columnDefinition = "DATETIME")
    private Timestamp updatedAt;


    //constructors
    public QuoteEntity() {

    }

    public QuoteEntity(long sessionStateId, String baseCurrency, double baseAmount, String foreignCurrency, double foreignAmount, int accepted) {
        this.sessionStateId = sessionStateId;
        this.baseCurrency = baseCurrency;
        this.baseAmount = baseAmount;
        this.foreignCurrency = foreignCurrency;
        this.foreignAmount = foreignAmount;
        this.accepted = accepted;
    }
    //methods
    public long getSessionStateId() {
        return sessionStateId;
    }

    public long getId() {
        return id;
    }

    public String getBaseCurrency() {
        return baseCurrency;
    }

    public void setBaseCurrency(String baseCurrency) {
        this.baseCurrency = baseCurrency;
    }

    public double getBaseAmount() {
        return baseAmount;
    }

    public void setBaseAmount(double baseAmount) {
        this.baseAmount = baseAmount;
    }

    public String getForeignCurrency() {
        return foreignCurrency;
    }

    public void setForeignCurrency(String foreignCurrency) {
        this.foreignCurrency = foreignCurrency;
    }

    public double getForeignAmount() {
        return foreignAmount;
    }

    public void setForeignAmount(double foreignAmount) {
        this.foreignAmount = foreignAmount;
    }

    public int isAccepted() {
        return accepted;
    }

    public void setAccepted(int accepted) {
        this.accepted = accepted;
    }
}
